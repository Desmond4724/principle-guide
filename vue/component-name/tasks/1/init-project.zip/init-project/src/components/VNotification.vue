<template>

</template>

<script>
export default {
	name: 'v-notification'
}
</script>