<template>
<h4>It is alert</h4>
</template>


<script>
export default {
	name: 'V_ALERT'
}
</script>