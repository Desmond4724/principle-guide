<template>
	<h4>It is card</h4>
</template>

<script>
export default {
	name: 'vcard'
}
</script>