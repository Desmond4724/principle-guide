<template>
	<V_ALERT/>
	<Vcard/>
	<VNotification/>
</template>
<script>
import V_ALERT from "./components/vAlert.vue";
import Vcard from "./components/VCARD.vue";
import VNotification from "./components/VNotification.vue";

export default {
	components: {VNotification, Vcard, V_ALERT}
}
</script>