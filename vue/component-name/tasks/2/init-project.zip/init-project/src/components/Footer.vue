<template>
<div>Footer</div>
</template>

<script>
export default {
  name: 'Footer'
}
</script>