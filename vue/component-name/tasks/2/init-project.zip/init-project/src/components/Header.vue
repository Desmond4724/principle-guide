<template>
  <div>Header</div>
</template>

<script>
export default {
  name: 'Header'
}
</script>