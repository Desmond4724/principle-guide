<template>
  <div>Main</div>
</template>

<script>
export default {
  name: 'Main'
}
</script>